function num() {
  num = document.createElement("number").value;
}
